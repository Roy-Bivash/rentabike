export class CreateMessageDto {
    raison: string;
    mail: string;
    content: string;
}
