export class CreateVeloDto {}
