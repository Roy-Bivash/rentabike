export class UpdateFunctionnal {
    id: string;
    fonctionnel: boolean
}