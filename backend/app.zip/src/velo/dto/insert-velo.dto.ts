export class InsertVeloDto {
    station: string;
    type: string;
}