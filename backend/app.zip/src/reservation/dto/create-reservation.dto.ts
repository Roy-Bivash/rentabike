export class CreateReservationDto {
    station_id: string;
    type_velo: string;
}
