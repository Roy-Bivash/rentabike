export class DeposerVeloDto {
    station_id: string;
    commentaire: string;
    vote: string
}
