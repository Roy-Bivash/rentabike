export class Reservation {}
