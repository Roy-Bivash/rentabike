export class CreateHistoriqueDto {}
