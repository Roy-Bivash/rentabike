export class ChangeRoleDto {
    userId: number;
    role: string;
}
  