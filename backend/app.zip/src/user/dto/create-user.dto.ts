export class CreateUserDto {
    nom: string;
    prenom: string;
    password: string;
    tel: string;
    mail: string;
}
  