export class LoginDto {
    email: string;
    password: string;
  }
  