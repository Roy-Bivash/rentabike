export class CreateStationDto {}
